(() => {
  const $ = id => document.getElementById(id);
  const keys = { backend: 'mememob.v4.backend' };
  const stored = localStorage.getItem(keys.backend) || '';
  $('backendUrl').value = stored;
  const setStatus = (id, msg, bad=false) => { const el=$(id); el.textContent=msg; el.style.borderColor=bad?'#ef4444':''; };
  const backend = () => $('backendUrl').value.trim().replace(/\/$/, '');
  $('saveBackend').addEventListener('click', () => {
    const url=backend();
    if (!/^https:\/\//i.test(url)) return setStatus('backendStatus','Enter a valid HTTPS backend URL.',true);
    localStorage.setItem(keys.backend,url); setStatus('backendStatus','Backend URL saved on this device. Tap Check connection to verify it.');
  });
  async function api(path, options={}) {
    const url=backend(); if (!url) throw new Error('Save your backend URL first.');
    const res=await fetch(url+path,{...options,headers:{'Content-Type':'application/json',...(options.headers||{})}});
    const data=await res.json().catch(()=>({error:'Backend returned a non-JSON response.'}));
    if(!res.ok) throw new Error(data.error || `Request failed (${res.status})`); return data;
  }
  $('checkBackend').addEventListener('click', async()=>{
    setStatus('backendStatus','Checking backend…');
    try { const d=await api('/api/health'); setStatus('backendStatus',`Connected · ${d.service||'Meme Mob API'} · ${d.aiConfigured?'AI key detected':'AI key not configured'} · ${d.metaConfigured?'Meta configured':'Meta not configured'}`); }
    catch(e){setStatus('backendStatus',e.message,true);}
  });
  $('generateAiImage').addEventListener('click', async()=>{
    const prompt=$('imagePrompt').value.trim(); if(!prompt) return setStatus('aiImageStatus','Enter an image idea first.',true);
    $('generateAiImage').disabled=true; setStatus('aiImageStatus','Generating image… this can take a little while.'); $('aiImageResult').hidden=true;
    try { const d=await api('/api/generate-image',{method:'POST',body:JSON.stringify({prompt})});
      if(!d.imageDataUrl) throw new Error('Backend did not return image data.');
      $('aiImageResult').src=d.imageDataUrl; $('aiImageResult').hidden=false; setStatus('aiImageStatus','Image generated. Review it before using or publishing.');
    } catch(e){setStatus('aiImageStatus',e.message,true);} finally {$('generateAiImage').disabled=false;}
  });
  $('publishInstagram').addEventListener('click',async()=>{
    if(!$('confirmPublish').checked) return setStatus('publishStatus','Review the content and tick the rights/review confirmation first.',true);
    const imageUrl=$('publishImageUrl').value.trim(), caption=$('publishCaption').value.trim();
    if(!/^https:\/\//i.test(imageUrl)) return setStatus('publishStatus','Enter a publicly accessible HTTPS image URL.',true);
    if(!caption) return setStatus('publishStatus','Enter a caption before publishing.',true);
    if(!confirm('Publish this reviewed image to the connected Instagram account now?')) return;
    $('publishInstagram').disabled=true; setStatus('publishStatus','Sending publish request…');
    try { const d=await api('/api/instagram/publish',{method:'POST',body:JSON.stringify({imageUrl,caption,confirmed:true})}); setStatus('publishStatus',d.message||`Publish request completed. Media ID: ${d.id||'returned by Meta'}`); }
    catch(e){setStatus('publishStatus',e.message,true);} finally {$('publishInstagram').disabled=false;}
  });
})();
