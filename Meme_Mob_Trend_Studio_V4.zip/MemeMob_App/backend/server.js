import http from 'node:http';
import { URL } from 'node:url';

const PORT = Number(process.env.PORT || 8787);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const IG_USER_ID = process.env.IG_USER_ID || '';
const IG_ACCESS_TOKEN = process.env.IG_ACCESS_TOKEN || '';
const GRAPH_API_VERSION = process.env.GRAPH_API_VERSION || 'v23.0';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*';
const MAX_BODY = 1024 * 1024;

function send(res, status, body) {
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':ALLOWED_ORIGIN,'Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type'});
  res.end(JSON.stringify(body));
}
async function readJson(req) {
  let raw=''; for await (const chunk of req) { raw+=chunk; if(raw.length>MAX_BODY) throw new Error('Request body too large.'); }
  try { return JSON.parse(raw || '{}'); } catch { throw new Error('Invalid JSON body.'); }
}
const server=http.createServer(async(req,res)=>{
  if(req.method==='OPTIONS') return send(res,204,{});
  const url=new URL(req.url,'http://localhost');
  try {
    if(req.method==='GET' && url.pathname==='/api/health') return send(res,200,{service:'Meme Mob V4 API',aiConfigured:!!OPENAI_API_KEY,metaConfigured:!!(IG_USER_ID&&IG_ACCESS_TOKEN)});
    if(req.method==='POST' && url.pathname==='/api/generate-image') {
      if(!OPENAI_API_KEY) return send(res,503,{error:'AI image generation is not configured on the backend. Add OPENAI_API_KEY as an environment variable.'});
      const body=await readJson(req); const prompt=String(body.prompt||'').trim();
      if(!prompt || prompt.length>700) return send(res,400,{error:'Prompt is required and must be 700 characters or fewer.'});
      const response=await fetch('https://api.openai.com/v1/images/generations',{method:'POST',headers:{Authorization:`Bearer ${OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_IMAGE_MODEL||'gpt-image-1',prompt,size:'1024x1024',n:1})});
      const data=await response.json(); if(!response.ok) return send(res,response.status,{error:data.error?.message||'Image provider request failed.'});
      const item=data.data?.[0]; if(!item?.b64_json) return send(res,502,{error:'Image provider returned no base64 image. Check model/API access.'});
      return send(res,200,{imageDataUrl:`data:image/png;base64,${item.b64_json}`});
    }
    if(req.method==='POST' && url.pathname==='/api/instagram/publish') {
      if(!IG_USER_ID||!IG_ACCESS_TOKEN) return send(res,503,{error:'Instagram publishing is not configured. Set IG_USER_ID and IG_ACCESS_TOKEN on the backend.'});
      const body=await readJson(req); const imageUrl=String(body.imageUrl||'').trim(); const caption=String(body.caption||'').trim();
      if(body.confirmed!==true) return send(res,400,{error:'Explicit review confirmation is required.'});
      if(!/^https:\/\//i.test(imageUrl) || imageUrl.length>2000) return send(res,400,{error:'imageUrl must be a public HTTPS URL accessible to Meta.'});
      if(!caption || caption.length>2200) return send(res,400,{error:'Caption is required and must be 2,200 characters or fewer.'});
      const base=`https://graph.facebook.com/${GRAPH_API_VERSION}/${encodeURIComponent(IG_USER_ID)}`;
      const create=await fetch(`${base}/media`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({image_url:imageUrl,caption,access_token:IG_ACCESS_TOKEN})});
      const created=await create.json(); if(!create.ok||created.error) return send(res,502,{error:created.error?.message||'Meta media container creation failed.'});
      // Give Meta time to fetch the public image before publishing. For production, poll container status until FINISHED.
      await new Promise(r=>setTimeout(r,1500));
      const publish=await fetch(`${base}/media_publish`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({creation_id:created.id,access_token:IG_ACCESS_TOKEN})});
      const published=await publish.json(); if(!publish.ok||published.error) return send(res,502,{error:published.error?.message||`Meta publish failed; container ${created.id} may need status checking.`});
      return send(res,200,{id:published.id,message:'Meta accepted the publish request.'});
    }
    return send(res,404,{error:'Route not found.'});
  } catch(e) { return send(res,500,{error:e.message||'Unexpected server error.'}); }
});
server.listen(PORT,()=>console.log(`Meme Mob V4 API listening on ${PORT}`));
