# Meme Mob V4 backend

This Node.js 20+ starter keeps provider credentials on a server, not in GitHub Pages/browser code.

## Run locally
1. Install Node.js 20+.
2. `cd backend` then `npm start` (no npm dependencies required).
3. Set the environment variables listed in `.env.example` in your host dashboard. Do not commit real secrets.
4. In Meme Mob V4, enter the backend HTTPS URL and tap **Check connection**.

## Deploy
Deploy this folder as a Node web service on a server host that supports Node.js 20 and environment variables. Set `ALLOWED_ORIGIN` to your exact GitHub Pages origin. Set secrets through the host's environment-variable UI, never in source files.

## AI image endpoint
`POST /api/generate-image` with `{ "prompt": "..." }`. Requires an OpenAI API key, account access to the configured image model, and billing. It returns a data URL for preview. The generated data URL is not a public URL and cannot itself be sent to Instagram's publishing API. Upload the reviewed image to a public HTTPS media host you control before publishing.

## Instagram publishing endpoint
`POST /api/instagram/publish` with `{ "imageUrl":"https://...", "caption":"...", "confirmed":true }`. Requires an eligible Instagram Professional account, a Meta app configured for the appropriate Instagram API flow, approved permissions/access token, correct account ID, and a public image URL Meta can fetch. API permissions and Graph API version may change; verify current Meta documentation before production use. This minimal starter uses an image-post flow only, not Reels or licensed trending audio.

## Production hardening required
This is a starter, not a production-ready public API. Before opening it to other users, add authentication, per-user authorization, rate limiting, abuse prevention, request logging with secrets redacted, image moderation, upload/storage management, robust Meta container-status polling/retries, token refresh/revocation, and cost controls. Restrict CORS to your site; CORS is not authentication. Do not expose this backend to public use with no authentication.
